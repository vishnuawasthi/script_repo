/**
 * http://usejsdoc.org/
 */
// users.js
/*var Users = function() {
 this.firsName = "";
 this.lastName = "";
 this.email = "";
 this.username = "";
 this.password = "";

 }*/
/*   function Users() {
	this.firsName = "";
	this.lastName = "";
	this.email = "";
	this.username = "";
	this.password = "";

};*/

function Users(firstName,lastName,email,username,password) {
	this.firsName = firstName;
	this.lastName = lastName;
	this.email = email;
	this.username = username;
	this.password = password;

	return this;
};

module.exports.Users = Users;