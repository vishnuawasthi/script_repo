/**
 * 
 */

// server.js
// server.js
// BASE SETUP
// =============================================================================
// call the packages we need
var express = require('express'); // call express
var app = express(); // define our app using express
var bodyParser = require('body-parser');
var mysql = require('mysql');
var models = require('./models/users.js');

// configure app to use bodyParser()
// this will let us get the data from a POST
app.use(bodyParser.urlencoded({
	extended : true
}));
app.use(bodyParser.json());

var port = process.env.PORT || 8080; // set our port

// Create the connection with mysql
// First you need to create a connection to the db
var con = mysql.createConnection({
	host : 'localhost',
	port : '3306',
	user : 'root',
	database: 'test',
	password : 'root'
});

// ROUTES FOR OUR API
// =============================================================================
var router = express.Router(); // get an instance of the express Router

// test route to make sure everything is working (accessed at GET
// http://localhost:8080/api)
router.get('/', function(req, res) {
	res.json({
		message : 'hooray! welcome to our api!'
	});
});

/*
 * var Users = function (){ this.firsName; this.lastName; this.email;
 * this.username; this.password;
 *  };
 */

/* POST API */


function Employee(){
	this.firstName ;
	this.lastName;
	this.id;
}

var employes =[];
var   i =0;

router.post('/saveEmployee',function(req,res){
	console.log('saveEmployee - start');
	var emp = new Employee();
	emp.firstName = req.body.firstName;
	emp.lastName = req.body.lastName;
	emp.id = req.body.id;
	console.log(emp.firstName + " "+emp.lastName +"  "+emp.id);
	console.log(' emp   : '+emp);
	
	employes[i]=emp;
	i++;
	res.json(employes);
	console.log('saveEmployee - start');
});


router.get('/findById/:id',function(req,res){
	console.log('findById - start');
	var emp = new Employee();
//	res.json(employes);
	
	for(var j = 0;j<employes.length;j++){
		
		console.log('req.params.id : '+req.params.id);
		
		if(employes[j].id === req.params.id){
			res.json(employes[j]);
			return ;
		}
	}
	console.log('findById - end');
});


router.get('/mysql', function(req, res) {
	var data = [];
	con.connect(function(err) {
		if (err) {
			console.log('Error connecting to Db');
			return;
		}
		console.log('Connection established');
	});
	
	con.query('SELECT * FROM user',function(err,rows){
		  if(err) throw err;

		  // keeping data into response as a json response.
		  
		  for(var index =0 ;index < rows.length;index++){
			// console.log('username : '+rows[index].username);
			  
			var user =  new models.Users(rows[index].first_name,rows[index].last_name,rows[index].email,rows[index].username,rows[index].password);
		
			
			// user.username = rows[index].username;
			  
			  
			  data[index] = user;
		  }
		  res.json(data);
		  console.log('Data received from Db:\n');
		// console.log(rows);
		});
	con.end(function(err) {
		console.log('connecton is closed successfully.');
		// The connection is terminated gracefully
		// Ensures all previously enqueued queries are still
		// before sending a COM_QUIT packet to the MySQL server.
	});

	
});

// more routes for our API will happen here

// REGISTER OUR ROUTES -------------------------------
// all of our routes will be prefixed with /api
app.use('/api', router);

// START THE SERVER
// =============================================================================
app.listen(port);
console.log('Magic happens on port ' + port);