/**
 * http://usejsdoc.org/
 */

//utility.js

function isNull(value){
	
	
}
